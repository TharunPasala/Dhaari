## Q3
Dhaari: UPI for Skills. India's trusted rail from classroom to first paycheck.

## Q4
India built UPI so money could move with trust at population scale. Skills and student entitlements still move on paper, phone calls and faith.

The business problem: rural India's education-to-income pipeline leaks at three points.

1. Discovery leak. Rural students cannot see the careers, courses and schemes they already qualify for. ASER 2023 found only 5.6% of rural 14-18 year olds take any vocational training, and only 19.8% of girls own a phone.

2. Money leak. Scholarship and skilling funds move through manual, siloed verification. When the Ministry of Minority Affairs audited 1,572 flagged institutions on the National Scholarship Portal, 830 were fake or non-operational, costing the exchequer Rs 144.33 crore over five years. That is one scheme, in one ministry.

3. Trust leak. Employers cannot verify a rural youth's skill certificate in seconds, so they hire from known networks. The training never turns into a salary.

All three leaks share one root cause: there is no shared, tamper-proof record that schools, skill councils, scholarship authorities, banks and employers all trust.

Size of the opportunity:
1. India has over 24 crore school students, most in rural and semi-urban areas. Every one of them is a future applicant, credential holder and earner.
2. Thousands of crores flow every year through scholarship and skilling schemes via DBT. Every 1% of leakage removed goes back to a real student.
3. Every employer hiring entry-level talent pays for slow, manual verification today.

Whoever builds the trust layer for skills owns India's next UPI moment. Dhaari is that layer.

## Q5
Meet Lakshmi. She is 16, from a village in Andhra Pradesh, and the top student in her class. She repairs her neighbours' phones and keeps the accounts at her uncle's kirana shop. Nobody has told her those are two careers. Nobody has told her she qualifies for scholarships she will never claim. Her family shares one phone. The deadline she never hears about passes in silence.

Multiply Lakshmi by millions. That is the problem.

Who is impacted:

1. Rural students, especially girls and first-generation learners. They choose from the five careers their village knows, not the hundreds that exist. ASER 2023 shows about one in four rural 14-18 year olds cannot fluently read a Class 2 text in their own language, so text-heavy portals shut them out.

2. Parents. They pay middlemen for forms they cannot read, check or track.

3. Teachers. One teacher cannot track 100 students against thousands of schemes, deadlines and eligibility rules.

4. Government. Money meant for Lakshmi reaches fake institutions and ghost beneficiaries because verification is manual and each department keeps its own records. The Rs 144 crore minority scholarship fraud surfaced only after an audit, years later.

5. Employers and banks. They cannot verify a rural candidate's skills instantly, so they hire from known networks and lend only against collateral.

Why it must be solved now:

1. The demographic window is open but closing. Every untrained, unmatched young person is lost income that never comes back.

2. The rails already exist. UPI, DigiLocker, BHASHINI, DBT and now DRUNIX give India every part. What is missing is the layer that connects them for skills and entitlements.

3. Trust is the bottleneck, not information. More portals have not fixed this. A shared ledger that every institution trusts can.

4. The cost compounds. A missed scholarship at 16 becomes a dropout at 18 and an informal job at 20. Fixing the pipeline early changes a lifetime of earnings.

The question is not whether India will build trust infrastructure for skills. NPCI already proved with UPI that India can. The question is who builds it first.

## Q6
Dhaari is a voice-first AI career and entitlement platform for rural students, running on a DRUNIX trust layer. The AI finds the path. DRUNIX makes every step on it verifiable.

A. What the student experiences
1. Discover: a 10-minute voice conversation in Telugu first, then other Indian languages, using BHASHINI speech APIs. An LLM extracts interests, strengths and "hidden skills" from daily life and maps them to official NCO-2015 occupation codes and NSQF levels.
2. Widen: every course, scheme, apprenticeship and job sits on one skill-occupation graph. The student sees 15+ realistic careers, including vocational and non-STEM paths.
3. Qualify: a deterministic rules-as-code eligibility engine checks age, class, marks, category, income and location against scheme rules. The AI only explains the result by voice. It never invents a scheme.
4. Act: an event-driven Opportunity Radar sends voice alerts before deadlines through the app, WhatsApp or missed-call IVR. Facilitator mode lets one teacher manage 100 students on one shared phone.
5. Earn: verified credentials let employers shortlist in seconds. Scholarships and stipends release to the student's bank account on verified milestones.

B. The DRUNIX trust layer
A permissioned multi-organisation network with five member types:
1. Schools and the state education department
2. Sector skill councils and training partners
3. Scholarship authorities
4. Partner banks
5. Employers and CSR funders
Each runs its own peers and holds its own identity.

Chaincode in Go, four core contracts:
1. CredentialContract: issues, verifies and revokes skill and marks credentials. Only the document hash and issuer signature go on-chain. The document stays in DigiLocker.
2. EntitlementContract: turns an eligibility decision into a tokenised entitlement that can be redeemed once, by the right student, at an accredited institution. Duplicate claims and ghost institutions fail endorsement.
3. MilestoneContract: releases funds in tranches only when two independent organisations attest attendance, assessment or apprenticeship milestones.
4. ConsentContract: records the student's or guardian's consent for every data share, in line with the DPDP Act 2023.

Privacy: income, category and marks live in private data collections, shared only with the authority and bank that need them, through DRUNIX's KeyDB transient store. The shared ledger holds hashes and proofs, never personal data.

Scale: admission and scholarship season squeezes millions of applications into a few weeks. Lite Peers absorb the endorsement spike and scale horizontally, while Committing Peers and the stateless validation service keep commits stable. YugabyteDB as the state database powers SQL queries for district dashboards: funds released, fraud flags, and which pathways lead to income.

C. Technical specifications
1. Mobile: lightweight Android app, offline-first with SQLite and background sync, built for low-end shared phones.
2. Voice: BHASHINI and AI4Bharat models, with an offline speech-to-text fallback.
3. AI: LLM for profiling and explanation only. Eligibility and payouts are deterministic and auditable.
4. Backend: API services connected to DRUNIX through the Fabric Gateway SDK.
5. Ledger: DRUNIX v1.0 on Kubernetes, deployed with NPCI Falcon, Raft ordering.
6. Integrations: DigiLocker, UPI and DBT payout rails, WhatsApp Business API, IVR.

D. Current stage of development
1. Done: problem research, student and teacher personas, skill-occupation graph schema, eligibility rule model and business model (Lean Canvas).
2. Done: DRUNIX network topology, chaincode contract interfaces and data model.
3. Next 8 weeks: working prototype on the DRUNIX test network with three organisations (school, scholarship authority, bank), Credential and Entitlement contracts live, and a Telugu voice demo running end to end from voice profile to verified entitlement.
4. Then: a 90-day pilot in one Andhra Pradesh district with 5,000 students.

E. Dependencies for implementation
1. DRUNIX test network and NPCI sandbox access.
2. DigiLocker issuer and requester API access.
3. BHASHINI API access.
4. One pilot district or school cluster, and one scholarship authority willing to issue on-chain.
5. One partner bank for milestone-based payouts.

The result: a rural student speaks for ten minutes and walks away with a path, a verified record, and money that cannot be stolen on its way to her.

## Q7
DRUNIX is Dhaari's trust layer. Schools, skill councils, scholarship authorities, banks and employers each run peers on one permissioned network. Go chaincode issues and verifies skill credentials, turns eligibility decisions into single-use tokenised entitlements, and releases scholarships only on multi-party attested milestones. Student data stays in KeyDB-backed private collections; the ledger holds only hashes. Lite Peers absorb admission-season spikes, the stateless validation service scales as districts join, and YugabyteDB powers SQL dashboards on funds and outcomes. The AI finds the path. DRUNIX makes every rupee and certificate on it verifiable.

## Q8
1. Lite Peer / Committing Peer separation: scholarship and admission seasons create huge, short endorsement spikes. We scale Lite Peers for those weeks without slowing commits.
2. Stateless validation service: validation load grows as more districts, skill councils and banks join. We scale one service instead of every peer.
3. YugabyteDB: officials need SQL answers, such as funds released per district, duplicate claims per institution and pathway-to-income outcomes. LevelDB cannot query this and CouchDB lacks joins and aggregates. Distributed SQL fits.
4. KeyDB private data: income, category and marks are sensitive. Private collections share them only with the authority and bank that need them, with fewer network calls. The ledger stores hashes only, supporting DPDP compliance.
5. Chaincode (Go): Credential, Entitlement, Milestone and Consent contracts encode rules no single party can change alone.
6. Multi-organisation design: five member types, each with its own identity and endorsement role. Releasing funds needs two independent attestations.
7. Falcon: Kubernetes deployment and network management for a fast district pilot.
8. Other: DigiLocker, UPI and DBT payouts, BHASHINI speech, Fabric Gateway SDK.

## Q9
Methodology: we track one North Star, rupees unlocked per student, plus rupees protected from leakage. Each figure below uses stated assumptions that the pilot is designed to test.

1. Rupees unlocked (one-district pilot)
Formula: students onboarded x share matched to a new entitlement x share who successfully apply x average annual entitlement.
Pilot: 5,000 students x 30% x 50% x Rs 10,000 = Rs 75 lakh unlocked in year one, in one district.
Across all 26 Andhra Pradesh districts at the same rate: about Rs 19.5 crore a year.

2. Leakage prevented
The minority scholarship audit found Rs 144.33 crore lost through 830 fake institutions over five years, about Rs 29 crore a year, in a single scheme. On Dhaari, a fake institution or duplicate beneficiary fails endorsement before money moves. Blocking that one pattern nationally protects about Rs 29 crore every year.

3. Time saved
Employer credential checks drop from days of calls and letters to one ledger query in seconds. One teacher manages 100 student profiles on one device.

4. Livelihood outcomes
Target: 1 in 5 active students secures a scholarship, apprenticeship or paid work within 12 months.

5. Verifiable by design
Every outcome is recorded by milestone contracts and attested by two organisations. Our impact numbers will not be self-reported. They will be read from the ledger.

## Q10
1. We fuse two hard things: AI that finds the path and a DRUNIX ledger that verifies every step. Others do one.
2. Deterministic eligibility on a unified NCO/NSQF skill graph: auditable, zero invented schemes, slow to copy.
3. Data network effect: every verified placement shows which pathways lead to income, district by district. That dataset grows daily and cannot be bought.
4. Built for real Bharat: Telugu-first, voice-first, offline-first, one shared phone.
5. Proven builders: our lead has already delivered working AI automation for a senior officer at South Central Railway, Guntur Division.

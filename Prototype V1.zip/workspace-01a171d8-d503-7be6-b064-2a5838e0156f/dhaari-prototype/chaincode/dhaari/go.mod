module github.com/dhaari/chaincode

go 1.22
